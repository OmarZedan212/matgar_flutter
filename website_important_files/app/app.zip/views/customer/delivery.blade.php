@extends('layouts.app')
@section('title','Delivery')

@section('style')
<style>
.form-card {
    background: var(--surface);
    padding: 30px;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
}
.content-header h2 {
    font-size: 1.5rem;
    color: var(--text-main);
    margin-left: 24px;
}
.input-group label {
    display: block;
    margin-bottom: 8px;
    font-size: 0.9rem;
    font-weight: 600;
}
input, select, textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    outline: none;
}
.btn-primary {
    background: var(--primary);
    color: white;
    padding: 10px 25px;
    border-radius: var(--radius);
    border: none;
    cursor: pointer;
}
.cart-container { max-width:1200px; margin:3rem auto; display:flex; gap:30px; }
.cart-items { flex:2; }
.cart-item { display:flex; align-items:center; padding:20px 0; border-bottom:1px solid #eee; }
.item-img { width:80px; height:80px; border:1px solid #eee; border-radius:8px; padding:5px; margin-right:20px; }
.item-img img { width:100%; height:100%; object-fit:contain; }
.item-details { flex:1; }
.item-actions { display:flex; gap:10px; align-items:center; }
</style>
@endsection

@section('content')
    <div id="profile" class="tab-pane">
        <header class="content-header"><h2>Delivery</h2></header>
        <div class="form-card">
            <form id="profileForm">
                <div class="row">
                    <div class="input-group"><label>First Name</label><input type="text" value="John"></div>
                    <div class="input-group"><label>Last Name</label><input type="text" value="Doe"></div>
                </div>
                <div class="input-group"><label>Email</label><input type="email" value="john.doe@example.com"></div>
                <div class="input-group"><label>Phone</label><input type="tel" value="+1 234 567 890"></div>
                <div class="form-actions">
                    <button type="submit" class="btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
        <h3>Your Cart</h3>
        <hr style="border:0;border-top:1px solid #eee;margin-bottom:20px;">
            <div class="cart-item">
        {{-- Product Image --}}
        <div class="item-img">
            <a href="{{ route('customer.product', $item->product->id) }}">
                <img src="{{ $imgUrl }}" alt="{{ $item->product->name }}">
            </a>
        </div>

        {{-- Product Details --}}
        <div class="item-details">
            <div style="font-weight:600">
                <a href="{{ route('customer.product', $item->product->id) }}" style="text-decoration:none; color:inherit;">
                    {{ $item->product->name }}
                </a>
            </div>
@endsection

@section('scripts')
<script>

</script>
@endsection