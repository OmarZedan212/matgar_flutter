<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Seller;
use App\Models\CategoryGroup;

class DashboardController extends Controller
{
    public function index() { 
        
        $seller_id = Seller::where("user_id", auth()->id())->first("id");
        if(!isset($seller_id->id)){
            return "Seller Not Found";
        } 
        $inventoryData = Product::where("seller_id", $seller_id->id)->with("category")->get();
        return view('seller.index', compact('inventoryData')); 
    }
    public function store_product(Request $request)
    {
        $data = $request->validate([
            'name'        => 'required|string|max:255',
            'price'       => 'required|numeric|min:0',
            'stock'       => 'required|integer|min:0',
            'category_id' => 'nullable|integer|exists:categories,id',
            'description' => 'nullable|string',
            'image'       => 'nullable|image|max:2048',
        ]);

        $seller_id = Seller::where("user_id", auth()->id())->first("id");

        if(!isset($seller_id->id)){
            return "Seller Not Found";
        } 

        $data['seller_id'] = $seller_id->id;

        $product = Product::create($data);
        $data2 = [];
        if ($request->hasFile('image')) {
            $productId = $product->id; 

            $filename = $productId . '.' . $request->file('image')->getClientOriginalExtension();

            $data2['image_path'] = $request->file('image')
                ->storeAs('products', $filename, 'public');
        }
        $product->update($data2);
        $product->load('category:id,name');
        return response()->json([
            'message' => 'Product created successfully',
            'product' => $product,
        ]);
    }

    public function update_product(Request $request)
    {
        $product = Product::find($request->id);
        $data = $request->validate([
            'name'        => 'required|string|max:255',
            'price'       => 'required|numeric|min:0',
            'stock'       => 'required|integer|min:0',
            'category_id' => 'nullable|integer|exists:categories,id',
            'description' => 'nullable|string',
            'image'       => 'nullable|image|max:2048',
        ]);
        if ($request->hasFile('image')) {
            
            $filename = $product->id . '.' . $request->file('image')->getClientOriginalExtension();

            $data['image_path'] = $request->file('image')
                ->storeAs('products', $filename, 'public');
        }
        $seller_id = Seller::where("user_id", auth()->id())->first("id");
        if(!isset($seller_id->id)){
            return "Seller Not Found";
        } 
        $data['seller_id'] = $seller_id->id;
        $product->update($data);
        $product->load('category:id,name');
        return response()->json([
            'message' => 'Product updated successfully',
            'product' => $product,
        ]);
    }
    public function delete_product($id){
        Product::where('id', $id)->delete();

        return response()->json([
            'message' => 'Product deleted successfully',
        ]);
    }
    public function update_order_status(Request $request){
        return $request;
    }
    

    public function dashboard(){
        return view("seller.dashboard");
    }
    public function inventory(){
        $seller_id = Seller::where("user_id", auth()->id())->first("id");
        if(!isset($seller_id->id)){
            return "Seller Not Found";
        } 
        $inventoryData = Product::where("seller_id", $seller_id->id)->with("category")->get();

        $category_groups = CategoryGroup::where('status', 'active')       
                            ->whereHas('categories', function ($q) {        
                                $q->where('status', 'active');                   
                            })
                            ->with([
                                'categories' => function ($q) {                  
                                    $q->where('status', 'active')
                                    ->orderBy('name');
                                }
                            ])
                            ->orderBy('name')
                            ->get();

        return view('seller.inventory', compact('inventoryData', 'category_groups'));
    }
    public function orders(){
        return view("seller.orders");
    }
    public function analytics(){
        return view("seller.analytics");
    }
    public function settings()
{
    $seller = Seller::where('user_id', auth()->id())->first();

    return view('seller.settings', compact('seller'));
}
public function update_settings(Request $request)
{
    $data = $request->validate([
        'shop_name'           => 'required|string|max:255',
        'description'         => 'nullable|string',

        'business_email'      => 'nullable|email|max:255',
        'support_phone'       => 'nullable|string|max:50',
        'address'             => 'nullable|string|max:255',

        'facebook_page'       => 'nullable|url|max:255',
        'instagram_profile'   => 'nullable|url|max:255',
    ]);

    $data['user_id'] = auth()->id();

    $seller = Seller::updateOrCreate(
        ['user_id' => auth()->id()], 
        $data            
    );

    return response()->json([
        'success'    => true,
        'store_name' => $seller->shop_name,
    ]);
}
}
